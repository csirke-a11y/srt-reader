import { useState, useRef, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Upload, 
  Play, 
  Pause, 
  Square, 
  RotateCcw, 
  FileText, 
  Volume2,
  Clock,
  AlertCircle
} from "lucide-react";
import type { Subtitle, SrtFile } from "@shared/schema";

function parseTimeToMs(timeStr: string): number {
  const [time, ms] = timeStr.split(",");
  const [hours, minutes, seconds] = time.split(":").map(Number);
  return (hours * 3600 + minutes * 60 + seconds) * 1000 + parseInt(ms || "0");
}

function parseSrt(content: string): Subtitle[] {
  const subtitles: Subtitle[] = [];
  const normalizedContent = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const blocks = normalizedContent.trim().split(/\n\n+/);

  for (const block of blocks) {
    const lines = block.trim().split("\n").map(line => line.trim());
    if (lines.length < 3) continue;

    const id = parseInt(lines[0]);
    if (isNaN(id)) continue;

    const timeMatch = lines[1].match(
      /(\d{2}:\d{2}:\d{2},\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2},\d{3})/
    );
    if (!timeMatch) continue;

    const startTimeFormatted = timeMatch[1];
    const endTimeFormatted = timeMatch[2];
    const startTime = parseTimeToMs(startTimeFormatted);
    const endTime = parseTimeToMs(endTimeFormatted);

    const text = lines
      .slice(2)
      .join("\n")
      .replace(/<[^>]*>/g, "")
      .trim();

    if (text) {
      subtitles.push({
        id,
        startTime,
        endTime,
        startTimeFormatted,
        endTimeFormatted,
        text,
      });
    }
  }

  return subtitles;
}

function formatTime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
  }
  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

export default function Home() {
  const [srtFile, setSrtFile] = useState<SrtFile | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [currentSubtitleIndex, setCurrentSubtitleIndex] = useState(-1);
  const [speed, setSpeed] = useState(1);
  const [isDragging, setIsDragging] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(true);
  const [hungarianVoice, setHungarianVoice] = useState<SpeechSynthesisVoice | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const timerRef = useRef<number | null>(null);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const subtitleListRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!("speechSynthesis" in window)) {
      setSpeechSupported(false);
      toast({
        title: "Figyelmeztetés",
        description: "A böngésződ nem támogatja a szövegfelolvasást.",
        variant: "destructive",
      });
      return;
    }

    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      const hungarian = voices.find(
        (v) => v.lang.startsWith("hu") || v.lang.includes("HU")
      );
      if (hungarian) {
        setHungarianVoice(hungarian);
      }
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, [toast]);

  const stopPlayback = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    window.speechSynthesis.cancel();
    setIsPlaying(false);
  }, []);

  const speakSubtitle = useCallback(
    (subtitle: Subtitle) => {
      window.speechSynthesis.cancel();

      const utterance = new SpeechSynthesisUtterance(subtitle.text);
      utterance.rate = speed;
      utterance.lang = "hu-HU";

      if (hungarianVoice) {
        utterance.voice = hungarianVoice;
      }

      utteranceRef.current = utterance;
      window.speechSynthesis.speak(utterance);
    },
    [speed, hungarianVoice]
  );

  const lastTickRef = useRef<number>(0);
  const speedRef = useRef<number>(speed);

  useEffect(() => {
    speedRef.current = speed;
  }, [speed]);

  const startPlayback = useCallback(() => {
    if (!srtFile || srtFile.subtitles.length === 0) return;

    setIsPlaying(true);
    lastTickRef.current = Date.now();

    timerRef.current = window.setInterval(() => {
      const now = Date.now();
      const delta = now - lastTickRef.current;
      lastTickRef.current = now;

      setCurrentTime((prevTime) => {
        const newTime = prevTime + delta * speedRef.current;
        if (newTime >= srtFile.totalDuration) {
          stopPlayback();
          setCurrentSubtitleIndex(-1);
          return 0;
        }
        return newTime;
      });
    }, 50);
  }, [srtFile, stopPlayback]);

  useEffect(() => {
    if (!srtFile || !isPlaying) return;

    const subtitle = srtFile.subtitles.find(
      (s) => currentTime >= s.startTime && currentTime < s.endTime
    );

    if (subtitle) {
      const newIndex = srtFile.subtitles.indexOf(subtitle);
      if (newIndex !== currentSubtitleIndex) {
        setCurrentSubtitleIndex(newIndex);
        speakSubtitle(subtitle);
      }
    } else if (currentSubtitleIndex !== -1) {
      const currentSub = srtFile.subtitles[currentSubtitleIndex];
      if (currentSub && currentTime >= currentSub.endTime) {
        setCurrentSubtitleIndex(-1);
      }
    }
  }, [currentTime, srtFile, isPlaying, currentSubtitleIndex, speakSubtitle]);

  useEffect(() => {
    if (currentSubtitleIndex >= 0 && subtitleListRef.current) {
      const element = subtitleListRef.current.querySelector(
        `[data-subtitle-index="${currentSubtitleIndex}"]`
      );
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }, [currentSubtitleIndex]);

  useEffect(() => {
    return () => {
      stopPlayback();
    };
  }, [stopPlayback]);

  const handleFileSelect = (file: File) => {
    if (!file.name.endsWith(".srt")) {
      toast({
        title: "Hibás fájl",
        description: "Kérlek válassz .srt kiterjesztésű fájlt!",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const subtitles = parseSrt(content);

      if (subtitles.length === 0) {
        toast({
          title: "Üres fájl",
          description: "A fájl nem tartalmaz érvényes feliratokat.",
          variant: "destructive",
        });
        return;
      }

      const totalDuration =
        subtitles[subtitles.length - 1].endTime + 1000;

      setSrtFile({
        filename: file.name,
        subtitles,
        totalDuration,
      });
      setCurrentTime(0);
      setCurrentSubtitleIndex(-1);
      stopPlayback();

      toast({
        title: "Sikeres betöltés",
        description: `${subtitles.length} felirat betöltve.`,
      });
    };

    reader.onerror = () => {
      toast({
        title: "Hiba",
        description: "Nem sikerült beolvasni a fájlt.",
        variant: "destructive",
      });
    };

    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
  };

  const handlePlayPause = () => {
    if (isPlaying) {
      stopPlayback();
    } else {
      startPlayback();
    }
  };

  const handleStop = () => {
    stopPlayback();
    setCurrentTime(0);
    setCurrentSubtitleIndex(-1);
  };

  const handleRestart = () => {
    stopPlayback();
    setCurrentTime(0);
    setCurrentSubtitleIndex(-1);
    setTimeout(() => {
      startPlayback();
    }, 100);
  };

  const handleSpeedChange = (value: number[]) => {
    const newSpeed = value[0];
    setSpeed(newSpeed);
    if (utteranceRef.current) {
      utteranceRef.current.rate = newSpeed;
    }
  };

  const handleSubtitleClick = (index: number) => {
    if (!srtFile) return;
    const subtitle = srtFile.subtitles[index];
    stopPlayback();
    setCurrentTime(subtitle.startTime);
    setCurrentSubtitleIndex(index);
  };

  const progressPercent = srtFile
    ? (currentTime / srtFile.totalDuration) * 100
    : 0;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <header className="text-center space-y-2">
          <h1 className="text-2xl font-semibold text-foreground flex items-center justify-center gap-2">
            <Volume2 className="h-7 w-7" />
            SRT Felirat Felolvasó
          </h1>
          <p className="text-sm text-muted-foreground">
            Töltsd fel az SRT fájlt és hallgasd meg időzítve
          </p>
        </header>

        {!speechSupported && (
          <Card className="border-destructive">
            <CardContent className="p-4 flex items-center gap-3">
              <AlertCircle className="h-5 w-5 text-destructive" />
              <p className="text-sm text-destructive">
                A böngésződ nem támogatja a Web Speech API-t. Próbálkozz Chrome vagy Edge böngészővel.
              </p>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardContent className="p-6">
            <div
              className={`
                border-2 border-dashed rounded-md p-8
                flex flex-col items-center justify-center gap-4
                transition-colors duration-200 cursor-pointer
                ${isDragging 
                  ? "border-primary bg-primary/5" 
                  : "border-muted-foreground/25 hover:border-muted-foreground/50"
                }
              `}
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={() => fileInputRef.current?.click()}
              data-testid="dropzone-upload"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".srt"
                onChange={handleFileInput}
                className="hidden"
                data-testid="input-file"
              />
              
              {srtFile ? (
                <>
                  <FileText className="h-12 w-12 text-primary" />
                  <div className="text-center">
                    <p className="font-medium text-foreground" data-testid="text-filename">
                      {srtFile.filename}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {srtFile.subtitles.length} felirat betöltve
                    </p>
                  </div>
                  <Button variant="outline" size="sm" data-testid="button-change-file">
                    Másik fájl választása
                  </Button>
                </>
              ) : (
                <>
                  <Upload className="h-12 w-12 text-muted-foreground" />
                  <div className="text-center">
                    <p className="font-medium text-foreground">
                      Húzd ide az SRT fájlt
                    </p>
                    <p className="text-sm text-muted-foreground">
                      vagy kattints a tallózáshoz
                    </p>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {srtFile && (
          <>
            <Card>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-4">
                    <span className="text-sm font-medium text-foreground">
                      Sebesség
                    </span>
                    <Badge variant="secondary" data-testid="badge-speed">
                      {speed.toFixed(1)}x
                    </Badge>
                  </div>
                  <Slider
                    value={[speed]}
                    onValueChange={handleSpeedChange}
                    min={0.5}
                    max={2}
                    step={0.1}
                    className="w-full"
                    data-testid="slider-speed"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0.5x</span>
                    <span>1.0x</span>
                    <span>2.0x</span>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-4">
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={handleRestart}
                    disabled={!speechSupported}
                    data-testid="button-restart"
                  >
                    <RotateCcw className="h-5 w-5" />
                  </Button>
                  <Button
                    size="lg"
                    onClick={handlePlayPause}
                    disabled={!speechSupported}
                    data-testid="button-play-pause"
                  >
                    {isPlaying ? (
                      <Pause className="h-6 w-6" />
                    ) : (
                      <Play className="h-6 w-6" />
                    )}
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={handleStop}
                    disabled={!speechSupported}
                    data-testid="button-stop"
                  >
                    <Square className="h-5 w-5" />
                  </Button>
                </div>

                <div className="space-y-2">
                  <Progress value={progressPercent} className="h-2" data-testid="progress-bar" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span className="flex items-center gap-1" data-testid="text-current-time">
                      <Clock className="h-3 w-3" />
                      {formatTime(currentTime)}
                    </span>
                    <span data-testid="text-total-time">
                      {formatTime(srtFile.totalDuration)}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Feliratok
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-80">
                  <div ref={subtitleListRef} className="p-4 space-y-2">
                    {srtFile.subtitles.map((subtitle, index) => (
                      <div
                        key={subtitle.id}
                        data-subtitle-index={index}
                        onClick={() => handleSubtitleClick(index)}
                        className={`
                          p-3 rounded-md cursor-pointer transition-all duration-200
                          ${index === currentSubtitleIndex
                            ? "bg-primary/10 border border-primary/30"
                            : "hover:bg-muted/50"
                          }
                        `}
                        data-testid={`subtitle-item-${index}`}
                      >
                        <div className="flex items-start gap-3">
                          <Badge 
                            variant={index === currentSubtitleIndex ? "default" : "outline"} 
                            className="shrink-0 font-mono text-xs"
                          >
                            {subtitle.startTimeFormatted.substring(0, 8)}
                          </Badge>
                          <p 
                            className={`
                              text-sm leading-relaxed
                              ${index === currentSubtitleIndex 
                                ? "text-foreground font-medium" 
                                : "text-muted-foreground"
                              }
                            `}
                          >
                            {subtitle.text}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </>
        )}

        <footer className="text-center text-xs text-muted-foreground">
          <p>
            A felolvasás a böngésző beépített Text-to-Speech funkcióját használja.
          </p>
        </footer>
      </div>
    </div>
  );
}
