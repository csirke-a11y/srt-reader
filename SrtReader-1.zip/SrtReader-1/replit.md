# SRT Reader Application

## Overview

This is a browser-based SRT (SubRip Subtitle) file reader application that provides timed text-to-speech playback of subtitle files. The application allows users to upload SRT files, control playback speed, and follow along with synchronized subtitle display. It's designed as a utility-focused productivity tool for accessibility and language learning purposes.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server, configured with hot module replacement (HMR)
- **Wouter** for lightweight client-side routing (instead of React Router)
- **TanStack Query (React Query)** for server state management and data fetching

**UI Component Library**
- **shadcn/ui** component system using the "new-york" style preset
- **Radix UI** primitives for accessible, unstyled component foundations
- **Tailwind CSS** for utility-first styling with custom theme configuration
- Material Design-inspired interface focusing on clarity and functionality over visual flair

**Styling System**
- Tailwind configured with custom CSS variables for theming
- HSL-based color system supporting light/dark modes
- Custom spacing primitives (2, 4, 6, 8 units) for consistent layouts
- Typography using Inter/Roboto fonts via Google Fonts CDN
- Component-specific design tokens for buttons, cards, badges with elevation effects

**State Management**
- Client-side SRT file parsing and subtitle timing logic handled in React components
- Browser's native Web Speech API (text-to-speech) for subtitle playback
- Local state management using React hooks (useState, useRef, useEffect)
- No server-side state persistence currently implemented

### Backend Architecture

**Server Framework**
- **Express.js** as the HTTP server framework
- Custom middleware for JSON parsing with raw body capture
- Request logging middleware tracking method, path, status, and duration
- Static file serving from the Vite build output

**Development vs Production**
- Development: Vite dev server integrated as Express middleware with HMR support
- Production: Pre-built static files served from `dist/public` directory
- TypeScript execution via `tsx` in development, compiled to CommonJS for production

**Build Process**
- **esbuild** for server-side TypeScript bundling
- Selective dependency bundling (allowlist approach) to reduce file system calls and improve cold start performance
- Separate client and server build steps orchestrated through npm scripts

### Data Storage Solutions

**Database Configuration**
- **Drizzle ORM** configured with PostgreSQL dialect
- Schema definition in TypeScript using Drizzle's type-safe API
- Database migrations managed in `./migrations` directory
- Connection via `DATABASE_URL` environment variable

**Current Storage Implementation**
- **In-Memory Storage** (`MemStorage` class) for development/testing
- Implements `IStorage` interface with user CRUD operations
- Uses JavaScript `Map` for data storage with UUID-based keys
- No persistence layer currently active (data lost on restart)

**Data Models**
- User model with username and ID fields
- Subtitle interface defining structure: id, start/end times (ms and formatted), text content
- SRT file interface containing filename, subtitle array, and total duration

### External Dependencies

**UI & Component Libraries**
- Radix UI suite (accordion, dialog, dropdown, select, slider, toast, etc.)
- Embla Carousel for carousel functionality
- Lucide React for icon components
- class-variance-authority and clsx for dynamic className composition
- react-day-picker for calendar/date selection

**Development Tools**
- Replit-specific plugins for development environment integration
- Vite plugins: runtime error overlay, cartographer (dev only), dev banner (dev only)
- PostCSS with Tailwind and Autoprefixer for CSS processing

**Validation & Forms**
- Zod for runtime type validation and schema definition
- React Hook Form with Hookform Resolvers for form state management
- Drizzle-Zod for database schema to Zod schema conversion

**Potential Future Integrations** (based on dependencies)
- Session management: express-session with connect-pg-simple or memorystore
- Authentication: Passport.js with local strategy
- API services: Axios for HTTP requests
- AI/ML: OpenAI API, Google Generative AI
- Payment processing: Stripe
- Email: Nodemailer
- File uploads: Multer
- WebSocket support: ws library
- Rate limiting: express-rate-limit

### Application-Specific Features

**SRT File Processing**
- Client-side SRT parsing handling various line-ending formats (CRLF, CR, LF)
- Timestamp parsing converting HH:MM:SS,mmm format to milliseconds
- Subtitle block extraction with validation of ID and timing format
- Multi-line subtitle text concatenation

**Playback Controls**
- Play/Pause/Stop/Restart functionality
- Variable speed control (0.5x to 2.0x) using range slider
- Progress indicator showing current position in subtitle timeline
- Auto-scroll to current subtitle in display area
- Visual highlighting of active subtitle

**Design Principles**
- Utility-first approach prioritizing function over form
- Consistent spacing using predefined Tailwind units
- Clear visual hierarchy with semibold headings and normal body text
- Accessible design using Radix UI's ARIA-compliant primitives
- Generous breathing room and clear visual feedback states