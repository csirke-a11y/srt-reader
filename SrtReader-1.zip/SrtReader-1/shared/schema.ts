import { z } from "zod";

export interface Subtitle {
  id: number;
  startTime: number;
  endTime: number;
  startTimeFormatted: string;
  endTimeFormatted: string;
  text: string;
}

export interface SrtFile {
  filename: string;
  subtitles: Subtitle[];
  totalDuration: number;
}

export const subtitleSchema = z.object({
  id: z.number(),
  startTime: z.number(),
  endTime: z.number(),
  startTimeFormatted: z.string(),
  endTimeFormatted: z.string(),
  text: z.string(),
});

export const srtFileSchema = z.object({
  filename: z.string(),
  subtitles: z.array(subtitleSchema),
  totalDuration: z.number(),
});

export type SubtitleInput = z.infer<typeof subtitleSchema>;
export type SrtFileInput = z.infer<typeof srtFileSchema>;
