# SRT Reader Application - Design Guidelines

## Design Approach
**Selected System:** Material Design-inspired utility interface
**Rationale:** This is a utility-focused productivity tool where clarity, functionality, and ease of use are paramount. The interface prioritizes efficient workflow over visual flair.

---

## Core Design Elements

### Typography
- **Primary Font:** Inter or Roboto via Google Fonts CDN
- **Headings:** font-semibold, text-2xl for main title
- **Body Text:** font-normal, text-base for subtitle content
- **Controls/Labels:** text-sm for UI elements
- **Current Subtitle Display:** text-lg font-medium for readability

### Layout System
**Spacing Primitives:** Use Tailwind units of **2, 4, 6, 8** (e.g., p-4, gap-6, m-8)
- Consistent padding: p-6 for cards, p-4 for controls
- Gap spacing: gap-4 for button groups, gap-6 for sections
- Generous breathing room around main content area

### Component Library

**File Upload Zone**
- Large drop zone with dashed border (border-2 border-dashed)
- Clear upload icon from Heroicons (document-arrow-up)
- File name display once uploaded
- Drag-and-drop visual feedback states

**Playback Controls**
- Icon buttons in horizontal row: Play/Pause, Stop, Restart
- Use Heroicons: play-circle, pause-circle, stop-circle, arrow-path
- Grouped together with gap-4
- Clearly labeled below icons

**Speed Control**
- Range slider (0.5x to 2.0x)
- Current speed display (e.g., "1.0x")
- Positioned prominently near playback controls

**Subtitle Display Area**
- Scrollable container showing all subtitles
- Current subtitle highlighted with distinct background
- Timestamp + text for each entry
- Auto-scroll to current subtitle

**Progress Indicator**
- Simple linear progress bar showing playback position
- Optional: Time elapsed / Total time display

### Layout Structure
```
┌─────────────────────────────┐
│  Header: SRT Felirat Olvasó │
├─────────────────────────────┤
│  [File Upload Zone]         │
│  Or [Filename.srt] loaded   │
├─────────────────────────────┤
│  Speed: [▬▬▬●▬▬▬] 1.0x     │
├─────────────────────────────┤
│  [▶] [■] [↻] Controls       │
├─────────────────────────────┤
│  ═════════ Progress         │
├─────────────────────────────┤
│  ┌───Subtitles List───────┐ │
│  │ 1. 00:00:08 PAPRIKA    │ │
│  │ 2. 00:01:20 Ez lesz... │ │
│  │ [HIGHLIGHTED CURRENT]  │ │
│  │ 3. 00:01:24 Szent ég...│ │
│  └─────────────────────────┘ │
└─────────────────────────────┘
```

**Container:** max-w-2xl mx-auto (centered, readable width)
**Single Column:** All elements stack vertically for clarity

### Visual Hierarchy
1. File upload (primary action when empty)
2. Playback controls (primary action when loaded)
3. Subtitle display (main content focus)
4. Speed control (secondary adjustment)

### Interaction Patterns
- **Upload:** Click or drag-and-drop
- **Controls:** Large touch targets (min 44px)
- **Subtitle Navigation:** Auto-scroll to current, manual scroll allowed
- **Speed:** Live update on slider change

### Animations
**Minimal, functional only:**
- Smooth highlight transition on current subtitle (duration-200)
- Upload zone border pulse on drag-over
- Progress bar smooth fill

---

## Hungarian Language Considerations
- All UI text in Hungarian
- Labels: "Fájl feltöltése", "Sebesség", "Lejátszás", "Megállítás"
- Clear, simple language for controls

---

## Images
**No images required** - This is a pure utility application focused on text processing and playback controls.